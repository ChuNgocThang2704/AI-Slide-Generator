import sys
import os
import time
import httpx

# Thiết lập UTF-8 cho console
sys.stdout.reconfigure(encoding='utf-8')

API_BASE = "http://20.196.113.144:8000"
FILE_PATH = r"e:\DemoDoan\BTLNMCNPM-Nhóm 18.pdf"
INSTRUCTION = "Làm slide chi tiết, học thuật để thuyết trình trên lớp đại học, bám sát các chương mục, quy trình nghiệp vụ và sơ đồ thiết kế trong file."

async def test_generation():
    if not os.path.exists(FILE_PATH):
        print(f"Error: File not found at {FILE_PATH}")
        return

    print("=== START COMBINED GENERATION TEST (FILE + PROMPT) ===")
    print(f"File: {os.path.basename(FILE_PATH)}")
    print(f"Instruction: '{INSTRUCTION}'")
    print(f"Connecting to API: {API_BASE}")

    async with httpx.AsyncClient(timeout=30.0) as client:
        # Gửi request multipart post
        with open(FILE_PATH, "rb") as f:
            files = {"file": (os.path.basename(FILE_PATH), f, "application/pdf")}
            data = {
                "text": INSTRUCTION,
                "plan": "ultra",
                "slide_theme": "modern",
                "generate_images": "true"
            }
            
            print("\nSending file and instruction to API...")
            resp = await client.post(f"{API_BASE}/api/generate-slide-full", data=data, files=files)
            
            if resp.status_code != 200:
                print(f"API Error: Status {resp.status_code}")
                print(resp.text)
                return
                
            resp_data = resp.json()
            task_id = resp_data.get("task_id")
            status = resp_data.get("status")
            print(f"Task created successfully. Task ID: {task_id}, Status: {status}")

            if status == "completed":
                download_url = f"{API_BASE}{resp_data.get('download_url')}"
                print(f"Task already completed! Download URL: {download_url}")
                return

            # Bắt đầu polling trạng thái
            print("\nPolling task status (every 3 seconds)...")
            start_time = time.time()
            while True:
                status_resp = await client.get(f"{API_BASE}/api/status/{task_id}")
                if status_resp.status_code != 200:
                    print(f"Error checking status: {status_resp.status_code}")
                    await asyncio.sleep(3)
                    continue
                
                status_data = status_resp.json()
                current_status = status_data.get("status")
                progress = status_data.get("progress", 0)
                
                print(f"[{int(time.time() - start_time)}s] Status: {current_status} | Progress: {progress}%")
                
                if current_status == "completed":
                    result = status_data.get("result", {})
                    download_url = f"{API_BASE}{result.get('download_url')}"
                    print(f"\n🎉 Slide generated successfully!")
                    print(f"Download URL: {download_url}")
                    
                    # Tải file về thư mục Downloads để user kiểm tra
                    download_path = os.path.join(r"C:\Users\nguye\Downloads", f"CSDLPT_Presentation_{task_id[:8]}.pptx")
                    print(f"Downloading slide to: {download_path}...")
                    
                    file_resp = await client.get(download_url, timeout=120.0)
                    with open(download_path, "wb") as out_f:
                        out_f.write(file_resp.content)
                    print(f"Download finished! Size: {len(file_resp.content)} bytes")
                    break
                    
                elif current_status == "error":
                    print(f"\n❌ Task failed: {status_data.get('result')}")
                    break
                
                elif current_status == "cancelled":
                    print("\n⏹️ Task was cancelled.")
                    break
                
                time.sleep(3)

if __name__ == "__main__":
    import asyncio
    asyncio.run(test_generation())
