from __future__ import annotations
import base64
import json
import re
from typing import Any, Dict, List, Optional, Callable, Awaitable

import httpx

from config import (
    IMAGE_FALLBACK_MODEL,
    IMAGE_FALLBACK_TIMEOUT_SEC,
    GEMINI_MODEL,
    IMAGE_HEIGHT,
    IMAGE_WIDTH,
    PEXELS_API_KEY,
    STOCK_PHOTO_ENABLE,
    GEMINI_API_KEY,
    GCP_VERTEX_AI_ENABLE,
    GCP_PROJECT_ID,
    GCP_REGION,
)

from services.stock_photos import fetch_external_image
from .semantics import (
    _semantic_context,
    _semantic_list,
    _detect_historical_region,
    _extract_year_token,
    _extract_historical_entity,
    _is_mostly_ascii,
    _has_vietnamese_diacritics,
)




async def _try_secondary_ai_image_fallback(
    client: httpx.AsyncClient,
    *,
    prompt: str,
    negative_prompt: str,
    payload_template: Dict[str, Any],
) -> Optional[bytes]:
    """Thử Gemini Imagen làm ảnh dự phòng thứ cấp.

    Thay thế Together/FLUX vốn thường xuyên gặp lỗi giới hạn tần suất (rate-limit).
    Sử dụng Google Cloud Vertex AI nếu được bật, nếu không sẽ chuyển sang AI Studio.
    """
    model = (IMAGE_FALLBACK_MODEL or "").strip()
    if not model or model.startswith("black-forest-labs") or model.startswith("imagen-3.0"):
        model = "imagen-4.0-fast-generate-001"

    width = int(payload_template.get("width") or IMAGE_WIDTH)
    height = int(payload_template.get("height") or IMAGE_HEIGHT)
    if width >= height:
        aspect_ratio = "1:1" if abs(width - height) < 128 else "4:3"
    else:
        aspect_ratio = "3:4"

    is_imagen4 = "imagen-4.0" in model
    headers: Dict[str, str] = {}
    use_vertex = GCP_VERTEX_AI_ENABLE and GCP_PROJECT_ID
    
    if use_vertex:
        from services.vertex_auth import get_vertex_access_token
        token = get_vertex_access_token()
        if not token:
            print("[slide_images] Vertex AI enabled but failed to obtain access token. Skipping.")
            return None
        headers["Authorization"] = f"Bearer {token}"
        url = (
            f"https://{GCP_REGION}-aiplatform.googleapis.com/v1/"
            f"projects/{GCP_PROJECT_ID}/locations/{GCP_REGION}/publishers/google/models/{model}:predict"
        )
    else:
        if not GEMINI_API_KEY:
            print("[slide_images] secondary AI fallback skipped: GEMINI_API_KEY not set")
            return None
        url_param = "?key=" + GEMINI_API_KEY
        if is_imagen4:
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:predict{url_param}"
            )
        else:
            url = (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:generateImages{url_param}"
            )

    if use_vertex or is_imagen4:
        req: Dict[str, Any] = {
            "instances": [
                {
                    "prompt": (prompt or "")[:2000]
                }
            ],
            "parameters": {
                "sampleCount": 1,
                "aspectRatio": aspect_ratio,
                "outputMimeType": "image/png",
                "personGeneration": "ALLOW_ADULT",
            }
        }
    else:
        req = {
            "prompt": {"text": (prompt or "")[:2000]},
            "number_of_images": 1,
            "aspect_ratio": aspect_ratio,
            "safety_filter_level": "BLOCK_MEDIUM_AND_ABOVE",
            "person_generation": "ALLOW_ADULT",
        }
    def _url_for_model(model_name: str) -> str:
        if use_vertex:
            return (
                f"https://{GCP_REGION}-aiplatform.googleapis.com/v1/"
                f"projects/{GCP_PROJECT_ID}/locations/{GCP_REGION}/publishers/google/models/{model_name}:predict"
            )
        url_param = "?key=" + GEMINI_API_KEY
        if "imagen-4.0" in model_name:
            return (
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model_name}:predict{url_param}"
            )
        return (
            f"https://generativelanguage.googleapis.com/v1beta/models/"
            f"{model_name}:generateImages{url_param}"
        )

    if model == "imagen-4.0-generate-001":
        model_attempts = ["imagen-4.0-fast-generate-001", model]
    else:
        model_attempts = [model]

    configured_timeout = float(IMAGE_FALLBACK_TIMEOUT_SEC)
    for attempt_index, attempt_model in enumerate(model_attempts):
        read_timeout = configured_timeout
        if attempt_index == 0 and len(model_attempts) > 1:
            read_timeout = min(configured_timeout, 45.0)
        timeout = httpx.Timeout(read_timeout, connect=min(25.0, read_timeout))
        try:
            resp = await client.post(
                _url_for_model(attempt_model),
                json=req,
                headers=headers,
                timeout=timeout,
            )
        except Exception as e:
            print(
                f"[slide_images] Gemini Imagen fallback failed "
                f"({attempt_model}, {type(e).__name__}): {e}"
            )
            continue

        if resp.status_code != 200:
            print(
                f"[slide_images] Gemini Imagen fallback HTTP {resp.status_code} ({attempt_model}): "
                f"{resp.text[:300]}"
            )
            continue
        data = resp.json()
        
        b64_val = None
        if "imagen-4.0" in attempt_model:
            # Định dạng phản hồi của Imagen 4: {"predictions": [{"bytesBase64Encoded": "<b64>", "mimeType": "image/png"}]}
            predictions = data.get("predictions") or []
            if predictions and isinstance(predictions[0], dict):
                b64_val = predictions[0].get("bytesBase64Encoded")
        else:
            # Định dạng phản hồi của Imagen 3: {"generatedImages": [{"image": {"imageBytes": "<b64>"}}]}
            generated = data.get("generatedImages") or []
            if generated and isinstance(generated[0], dict):
                image_obj = (generated[0] or {}).get("image") or {}
                b64_val = image_obj.get("imageBytes")

        if not isinstance(b64_val, str) or not b64_val.strip():
            print(f"[slide_images] Gemini Imagen fallback: no image data in response ({attempt_model})")
            continue
        raw = base64.b64decode(b64_val)
        if not raw:
            print(f"[slide_images] Gemini Imagen fallback: decoded bytes empty ({attempt_model})")
            continue
        # Imagen trả về JPEG/PNG; chấp nhận cả hai.
        if raw.startswith(b"\x89PNG") or raw.startswith(b"\xff\xd8\xff"):
            print(f"[slide_images] Gemini Imagen fallback succeeded ({attempt_model})")
            return raw
        print(
            f"[slide_images] Gemini Imagen fallback: unexpected format "
            f"(model={attempt_model}, first 4 bytes={raw[:4]!r})"
        )
    return None


def _remove_vietnamese_diacritics(text: str) -> str:
    mapping = {
        "à": "a", "á": "a", "ả": "a", "ã": "a", "ạ": "a",
        "ă": "a", "ằ": "a", "ắ": "a", "ẳ": "a", "ẵ": "a", "ặ": "a",
        "â": "a", "ầ": "a", "ấ": "a", "ẩ": "a", "ẫ": "a", "ậ": "a",
        "è": "e", "é": "e", "ẻ": "e", "ẽ": "e", "ẹ": "e",
        "ê": "e", "ề": "e", "ế": "e", "ể": "e", "ễ": "e", "ệ": "e",
        "ì": "i", "í": "i", "ỉ": "i", "ĩ": "i", "ị": "i",
        "ò": "o", "ó": "o", "ỏ": "o", "õ": "o", "ọ": "o",
        "ô": "o", "ồ": "o", "ố": "o", "ổ": "o", "ỗ": "o", "ộ": "o",
        "ơ": "o", "ờ": "o", "ớ": "o", "ở": "o", "ỡ": "o", "ợ": "o",
        "ù": "u", "ú": "u", "ủ": "u", "ũ": "u", "ụ": "u",
        "ư": "u", "ừ": "u", "ứ": "u", "ử": "u", "ữ": "u", "ự": "u",
        "ỳ": "y", "ý": "y", "ỷ": "y", "ỹ": "y", "ỵ": "y",
        "đ": "d",
        "À": "A", "Á": "A", "Ả": "A", "Ã": "A", "Ạ": "A",
        "Ă": "A", "Ằ": "A", "Ắ": "A", "Ẳ": "A", "Ẵ": "A", "Ặ": "A",
        "Â": "A", "Ầ": "A", "Ấ": "A", "Ẩ": "A", "Ẫ": "A", "Ậ": "A",
        "È": "E", "É": "E", "Ẻ": "E", "Ẽ": "E", "Ẹ": "E",
        "Ê": "E", "Ề": "E", "Ế": "E", "Ể": "E", "Ễ": "E", "Ệ": "E",
        "Ì": "I", "Í": "I", "Ỉ": "I", "Ĩ": "I", "Ị": "I",
        "Ò": "O", "Ó": "O", "Ỏ": "O", "Õ": "O", "Ọ": "O",
        "Ô": "O", "Ồ": "O", "Ố": "O", "Ổ": "O", "Ỗ": "O", "Ộ": "O",
        "Ơ": "O", "Ờ": "O", "Ớ": "O", "Ở": "O", "Ỡ": "O", "Ợ": "O",
        "Ù": "U", "Ú": "U", "Ủ": "U", "Ũ": "U", "Ụ": "U",
        "Ư": "U", "Ừ": "U", "Ứ": "U", "Ử": "U", "Ữ": "U", "Ự": "U",
        "Ý": "Y", "Ỳ": "Y", "Ỷ": "Y", "Ỹ": "Y", "Ỵ": "Y",
        "Đ": "D"
    }
    return "".join(mapping.get(c, c) for c in text)


def _stock_photo_queries(
    slide: Dict[str, Any],
    semantic: Dict[str, Any],
    content_type: str,
    risk: Optional[str],
) -> List[str]:
    """Xây dựng các truy vấn tìm kiếm cho các nhà cung cấp ảnh stock/tham chiếu dự phòng bên ngoài."""
    title = str(slide.get("title") or "").strip()
    context = _semantic_context(slide, max_chars=320)
    topic = str(semantic.get("main_topic") or title).strip()
    entities = _semantic_list(semantic.get("entities"))[:3]
    action = str(semantic.get("action") or "").strip()
    obj = str(semantic.get("object") or "").strip()
    queries: List[str] = []

    # Ưu tiên 1: Sử dụng các truy vấn tìm kiếm do LLM tạo ra nếu có
    llm_queries = _semantic_list(semantic.get("stock_queries"))
    if llm_queries:
        queries.extend(llm_queries)

    # Ưu tiên 2: Các truy vấn heuristic chuẩn
    if risk == "person_protected":
        queries.extend(entities[:2])
        if title:
            queries.append(title)
    elif content_type == "historical":
        region = _detect_historical_region(context) or ""
        year = _extract_year_token(context) or ""
        entity = _extract_historical_entity(context) or ""
        if entity:
            queries.append(" ".join(x for x in [entity, region, year] if x))
        if topic:
            queries.append(" ".join(x for x in [topic, region, year] if x))
        if title:
            queries.append(title)
    elif risk in {"cultural", "religious"}:
        queries.extend(entities[:1])
        if topic:
            queries.append(topic)
        if title:
            queries.append(title)
    else:
        businessish = " ".join(x for x in [topic, action, obj] if x).strip()
        if businessish:
            queries.append(businessish)
        if title:
            queries.append(title)
        if topic and obj and obj.lower() not in topic.lower():
            queries.append(f"{topic} {obj}")

    if context:
        queries.append(context)

    # Ưu tiên 3: Các phương án dự phòng đơn giản hơn (nhóm trung bình)
    if topic:
        queries.append(topic)
    for ent in entities:
        queries.append(ent)
    if obj:
        for part in obj.split(","):
            queries.append(part.strip())

    # Ưu tiên 4: Các phương án dự phòng theo domain chung (an toàn tối đa)
    is_vietnam = False
    if _has_vietnamese_diacritics(title) or _has_vietnamese_diacritics(context):
        is_vietnam = True
    elif _detect_historical_region(context) == "Vietnam":
        is_vietnam = True

    if is_vietnam:
        if content_type == "historical" or risk == "person_protected":
            queries.extend(["Vietnam history", "old Vietnam", "Vietnam traditional", "Vietnam peasant"])
        else:
            queries.extend(["Vietnam workspace", "Vietnam school", "Vietnam"])
    
    # Các truy vấn dự phòng theo domain chung
    domain = str(semantic.get("domain") or "general").strip().lower()
    if domain == "business":
        queries.extend(["business office meeting", "corporate workspace", "business professional"])
    elif domain == "technology":
        queries.extend(["technology computer coding", "digital workspace", "programming coding"])
    elif domain == "medical":
        queries.extend(["healthcare medical clinic", "doctor hospital", "medical laboratory"])
    elif domain == "education":
        queries.extend(["classroom school university", "students studying", "classroom teaching"])
    else:
        queries.extend(["workspace documentation", "office desk laptop", "office presentation"])

    # Lọc và giữ nguyên thứ tự: thử các truy vấn cụ thể (>=2 từ) trước, sau đó là các từ đơn dự phòng
    seen = set()
    ordered = []
    for q in queries:
        q_clean = " ".join(str(q or "").strip().split())
        if not q_clean:
            continue
        # Thay thế các thuật ngữ liên quan đến bản đồ bằng "documents" để tránh lấy phải ảnh stock có bản đồ quốc gia không chính xác
        q_clean = re.sub(r"\b(world map|country map|vietnam map|map of vietnam|map|maps)\b", "documents", q_clean, flags=re.IGNORECASE)
        q_clean = " ".join(q_clean.split())
        
        # Loại bỏ dấu tiếng Việt để tương thích với các công cụ tìm kiếm và kiểm tra ASCII
        q_ascii = _remove_vietnamese_diacritics(q_clean)
        
        if not q_ascii or q_ascii.lower() in seen or not _is_mostly_ascii(q_ascii):
            continue
        seen.add(q_ascii.lower())
        ordered.append(q_ascii)
        
    return ordered



def _stock_photo_providers(content_type: str, risk: Optional[str]) -> List[str]:
    """Ưu tiên Wikimedia cho nội dung thực tế/lịch sử; Pexels cho ảnh stock chung chung."""
    factual_reference_risks = {
        "person_protected",
        "cultural",
        "religious",
        "political_sensitive",
        "crisis_sensitive",
        "legal_sensitive",
        "identity_sensitive",
        "child_sensitive",
        "map_symbol_sensitive",
    }
    if risk in factual_reference_risks or content_type == "historical":
        return ["wikimedia", "pexels"]
    return ["pexels", "wikimedia"]


async def _gemini_stock_photo_queries(
    client: httpx.AsyncClient,
    slide: Dict[str, Any],
    semantic: Dict[str, Any],
    content_type: str,
    risk: Optional[str],
) -> List[str]:
    """Tạo các truy vấn tìm kiếm ảnh stock/tham chiếu ngắn bằng tiếng Anh cho các trường hợp ngữ nghĩa yếu."""
    if not GEMINI_API_KEY:
        return []
    title = str(slide.get("title") or "").strip()
    bullets = slide.get("bullets") or slide.get("content") or []
    if isinstance(bullets, str):
        bullet_text = bullets
    else:
        bullet_text = "\n".join(str(x) for x in bullets[:5])
    prompt = (
        "Create 5 concise English search queries for Wikimedia Commons or stock photo search.\n"
        "Goal: find real reference images for a presentation slide, not generate an image.\n"
        "Prefer factual event/person/place terms, official English names, years, country names, "
        "and broad fallback queries if exact images are unlikely.\n"
        "Avoid Vietnamese diacritics. Avoid invented scene descriptions.\n"
        "Return ONLY a JSON array of strings.\n\n"
        f"content_type: {content_type}\n"
        f"risk: {risk or ''}\n"
        f"title: {title}\n"
        f"semantic_topic: {semantic.get('main_topic') or ''}\n"
        f"entities: {semantic.get('entities') or []}\n"
        f"slide_text:\n{bullet_text[:1200]}"
    )
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{(GEMINI_MODEL or 'gemini-2.5-flash').strip()}:generateContent?key={GEMINI_API_KEY}"
    )
    req = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": 512,
            "thinkingConfig": {"thinkingBudget": 0},
        },
    }
    try:
        resp = await client.post(url, json=req, timeout=20.0)
        if resp.status_code != 200:
            return []
        data = resp.json()
        parts = (((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or [])
        text = "\n".join(str(p.get("text") or "") for p in parts if isinstance(p, dict)).strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.IGNORECASE | re.MULTILINE).strip()
        parsed = json.loads(text)
    except Exception:
        return []
    if not isinstance(parsed, list):
        return []
    queries: List[str] = []
    for item in parsed:
        q = " ".join(str(item or "").strip().split())
        if not q or not _is_mostly_ascii(q):
            continue
        queries.append(q[:120])
    return queries[:5]



async def _try_stock_photo_fallback(
    client: httpx.AsyncClient,
    slide: Dict[str, Any],
    semantic: Dict[str, Any],
    content_type: str,
    risk: Optional[str],
    vlm_validate_fn: Optional[Callable[[bytes, Dict[str, Any]], Awaitable[bool]]] = None,
) -> Optional[Dict[str, Any]]:
    if not STOCK_PHOTO_ENABLE:
        return None
    queries = _stock_photo_queries(slide, semantic, content_type, risk)
    weak_stock_queries = not _semantic_list(semantic.get("stock_queries")) or float(semantic.get("confidence") or 0.0) < 0.5
    if weak_stock_queries or content_type == "historical" or risk in {
        "person_protected",
        "cultural",
        "religious",
        "political_sensitive",
        "crisis_sensitive",
        "legal_sensitive",
        "identity_sensitive",
        "child_sensitive",
        "map_symbol_sensitive",
        "finance_sensitive",
    }:
        ai_queries = await _gemini_stock_photo_queries(client, slide, semantic, content_type, risk)
        if ai_queries:
            queries = ai_queries + queries
    return await fetch_external_image(
        client,
        queries=queries,
        providers=_stock_photo_providers(content_type, risk),
        pexels_api_key=PEXELS_API_KEY,
        vlm_validate_fn=vlm_validate_fn,
    )
